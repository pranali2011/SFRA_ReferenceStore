'use strict';

var server = require('server');
var URLUtils = require('dw/web/URLUtils');

  
   
server.post('Submit',function(req, res, next) {

		var CustomObjectMgr = require('dw/object/CustomObjectMgr');  
		var email = req.form.notifyemail_Pid; 
		var productID = req.form.productID; 
		var returnUrl = URLUtils.url('NotifyForm-Submit').toString();  
		
		
		
         var Transaction = require('dw/system/Transaction');
     try {
         Transaction.wrap(function () {        
        	 var CustomObject = CustomObjectMgr.createCustomObject('NotifySubscription',(email +"-"+ productID));
        	  CustomObject.custom.email = email;
        	  CustomObject.custom.productID = productID;  

        	  res.render('NotifyResult', {  
     		    email : email,
     		   productID : productID  
     		    });     
         });     
         
     } catch (e) {
    	 var err = e;  
    	 var Resource = require('dw/web/Resource');
    	 res.json({  
      		success: false,  
      		
              error: [Resource.msg('error.subscriptionexists', 'notify', null)]
          });
  
     }
     
        
     next();
    });      
 


module.exports = server.exports();      